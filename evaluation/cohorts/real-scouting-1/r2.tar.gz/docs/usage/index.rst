=====
Usage
=====

This guide demonstrates building a complete blog system using Advanced Alchemy's features. We'll create a system that supports:

- Posts with tags and slugs
- Tag management with automatic deduplication
- Efficient querying and pagination
- Type-safe database operations
- Schema validation and transformation

.. toctree::
    :maxdepth: 2
    :caption: Core Features

    modeling/index
    repositories/index
    services
    routing
    caching
    cli
    database_seeding

.. toctree::
    :maxdepth: 2
    :caption: Framework Integration

    frameworks/litestar
    frameworks/flask
    frameworks/fastapi
    frameworks/sanic
    frameworks/starlette

The guide follows a practical approach:

1. **Modeling**: Define SQLAlchemy models with Advanced Alchemy's enhanced base classes
2. **Repositories**: Implement type-safe database operations using repositories
3. **Services**: Build business logic with automatic schema validation
4. **Framework Integration**: Integrate with Litestar and FastAPI

Each section includes:

- Concepts and usage overview
- Complete code examples
- Best practices
- Performance considerations
- Error handling strategies

Prerequisites
-------------

- Python 3.9+
- SQLAlchemy 2.0+
- Basic understanding of SQLAlchemy and async programming
- Basic understanding of Pydantic or Msgspec
